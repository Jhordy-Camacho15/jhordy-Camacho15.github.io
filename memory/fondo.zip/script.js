document.addEventListener('DOMContentLoaded', () => {
  showHome();
});

function showHome() {
  const app = document.getElementById('app');
  app.innerHTML = `
    <div class="container home-container">
      <button id="playBtn" class="main-btn">JUGAR AHORA</button>
    </div>
  `;
  document.getElementById('playBtn').onclick = showWorlds;
}

function showWorlds() {
  const app = document.getElementById('app');
  app.innerHTML = `
    <div class="container">
      <h2>Elige un Mundo</h2>
      <div style="display:flex;flex-direction:column;gap:16px;">
        <button onclick="showLevels('azul')" style="background:#2196f3;color:#fff;">🔵 Mundo Azul</button>
        <button onclick="showLevels('amarillo')" style="background:#ffeb3b;color:#333;">🟡 Mundo Amarillo</button>
        <button onclick="showLevels('rojo')" style="background:#f44336;color:#fff;">🔴 Mundo Rojo</button>
      </div>
      <button onclick="showHome()" style="margin-top:24px;">Volver</button>
    </div>
  `;
}

window.showLevels = function(world) {
  const app = document.getElementById('app');
  app.innerHTML = `
    <div class="container">
      <h2>Niveles de ${world.charAt(0).toUpperCase() + world.slice(1)}</h2>
      <div style="display:flex;flex-direction:column;gap:12px;">
        <button onclick="showLevel1('${world}')" style="opacity:1;">Nivel 1</button>
        <button disabled style="opacity:0.5;">Nivel 2</button>
        <button disabled style="opacity:0.5;">Nivel 3</button>
      </div>
      <button onclick="showWorlds()" style="margin-top:24px;">Volver</button>
    </div>
  `;
}

window.showLevel1 = function(world) {
  const app = document.getElementById('app');
  app.innerHTML = `
    <div class="container">
      <h2>Ejercicio 1</h2>
      <div style="margin:24px 0;">
        <span>🍊🍊🍊 + 🍊🍊 = ?</span>
      </div>
      <div style="display:flex;gap:12px;">
        <button onclick="alert('Incorrecto')">3</button>
        <button onclick="alert('Incorrecto')">4</button>
        <button onclick="alert('¡Correcto!'); showLevel1_2('${world}');">5</button>
        <button onclick="alert('Incorrecto')">6</button>
      </div>
      <button onclick="showLevels('${world}')" style="margin-top:24px;">Volver</button>
    </div>
  `;
}

window.showLevel1_2 = function(world) {
  const app = document.getElementById('app');
  app.innerHTML = `
    <div class="container">
      <h2>Ejercicio 2</h2>
      <div style="margin:24px 0;">
        <span>1, 3, 5, ...</span>
      </div>
      <div style="display:flex;gap:12px;">
        <button onclick="alert('Incorrecto')">6</button>
        <button onclick="alert('¡Correcto!'); showLevels('${world}');">7</button>
        <button onclick="alert('Incorrecto')">8</button>
        <button onclick="alert('Incorrecto')">9</button>
      </div>
      <button onclick="showLevels('${world}')" style="margin-top:24px;">Volver</button>
    </div>
  `;
}